﻿using ExempleUtilisationBoVoyageFramework.UI;

namespace ExempleUtilisationBoVoyageFramework
{
    class Program
    {
        static void Main(string[] args)
        {
            var application = new Application();
            application.Demarrer();
        }
    }
}
